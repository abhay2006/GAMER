



function preload(){
 //load your images here 
 
  
}

function setup() {
  createCanvas(600, 600);
  
  //add code here
  
}

function draw() {

  //add code here
  
}

